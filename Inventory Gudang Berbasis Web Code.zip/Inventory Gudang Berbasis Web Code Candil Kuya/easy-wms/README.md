# Easy WMS

Aplikasi manajemen pergudangan berbasis web dengan menggunakan framework CodeIgniter 3

File database bisa ditemukan di /assets/db/easy_wms.sql

## Tampilan Dashboard

<p align="center">
  <img src="/assets/images/easy-wms.png" alt="Dashboard Screenshot">
</p>

## Cara Login

| User	|       Email				| Password |
|:-----:|:-----------------:|:--------:|
| Admin	| admin@easywms.com	| admin    |
| Sunu	| sunu@easywms.com	| sunu     |
| Amir	| amir@easywms.com	| amir     |

<img src="/assets/images/users.png" alt="Tabel User" height="105">

