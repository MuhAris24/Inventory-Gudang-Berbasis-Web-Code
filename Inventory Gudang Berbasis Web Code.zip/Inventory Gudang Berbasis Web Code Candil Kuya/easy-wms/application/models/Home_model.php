<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends MY_Model 
{
    public $table = 'barang_masuk';
}

/* End of file Home_model.php */
