<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Inputs_model extends MY_Model 
{
    public $table = 'barang_masuk';
}

/* End of file Inputs_model.php */
