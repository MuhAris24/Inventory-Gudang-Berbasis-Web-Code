<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Outputs_model extends MY_Model 
{
    public $table = 'barang_keluar';
}

/* End of file Outputs_model.php */
