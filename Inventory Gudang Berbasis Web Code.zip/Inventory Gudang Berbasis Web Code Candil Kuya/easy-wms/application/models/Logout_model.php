<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Logout_model extends MY_Model 
{
    protected $table = 'keranjang';
}

/* End of file Logout_model.php */
