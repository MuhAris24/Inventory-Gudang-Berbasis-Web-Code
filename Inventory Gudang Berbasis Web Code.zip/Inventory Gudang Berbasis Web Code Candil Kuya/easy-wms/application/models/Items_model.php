<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Items_model extends MY_Model 
{
    protected $table    = 'barang';
    protected $perPage  = 10;
}

/* End of file Items_model.php */
