<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cartin_model extends MY_Model 
{
    public $table = 'keranjang_masuk';
}

/* End of file Cartin_model.php */
